# ELTA Project: Apache NiFi with Docker

## Overview

This project demonstrates how to set up Apache NiFi (version 1.23.1) using Docker. The included Dockerfile prepares a containerized environment, installs required packages, and exposes the NiFi web interface.

## Table of Contents

- [Dockerfile Instructions](#dockerfile-instructions)
- [Building and Running the Docker Container](#building-and-running-the-docker-container)
- [Accessing Apache NiFi](#accessing-apache-nifi)
- [NiFi Processors in the Flow](#nifi-processors-in-the-flow)
- [Prerequisites](#prerequisites)
- [Troubleshooting](#troubleshooting)



## Dockerfile Instructions


### Dockerfile Contents

```dockerfile
# Use the official Apache NiFi image as the base image
FROM apache/nifi:1.23.1

# Switch to root user temporarily to install packages
USER root

# Install Vim and curl
RUN apt-get update && apt-get install -y vim curl

# Create directories and set permissions
RUN mkdir -p /nifi/input /nifi/output && \
    chmod 777 /nifi/input /nifi/output


# Switch back to the default NiFi user for security
USER nifi

# Expose port 8443 for the NiFi web interface
EXPOSE 8443
```

#### Explanation

- **Base Image**: Uses `apache/nifi:1.23.1` as the base image
- **Package Installation**: Installs `vim` and `curl` for command-line utilities
- **Directory Creation**: Creates `/nifi/input` and `/nifi/output` directories with full permissions
- **Port Exposure**: Exposes port 8443 for accessing NiFi's web interface

## Building and Running the Docker Container

### Step 1: Build the Docker Image

Navigate to the directory containing the Dockerfile and run:

```bash
docker build -t my-nifi-image .
```

- `-t my-nifi-image`: Tags the image as `my-nifi-image`

### Step 2: Run the Docker Container

Start the container with the following command:

```bash
docker run -d \
  --name nifi2 \
  -p 8443:8443 \
  -v ~/nifi/input:/nifi/input \
  -v ~/nifi/output:/nifi/output \
  my-nifi-image
```

- `-d`: Runs the container in detached mode
- `--name nifi2`: Assigns the name `nifi2` to the container
- `-p 8443:8443`: Maps host port 8443 to container port 8443
- `-v ~/nifi/input:/nifi/input` and `-v ~/nifi/output:/nifi/output`: Maps host directories for data persistence

## Accessing Apache NiFi

### Finding Username and Password

To obtain the credentials for accessing the NiFi UI, run:

```bash
docker logs nifi2 | grep -i "username"
docker logs nifi2 | grep -i "password"
```


Copy configuration flow.xml file into the container to 
docker cp /path/to/flow.xml.gz nifi2:/opt/nifi/nifi-current/conf/flow.xml.gz

To view the LogAttribute processor's logs, you need to configure the logback.xml file. 
Navigate to /opt/nifi/nifi-current/conf/logback.xml and add the following to the appenders.
```
<appender name="LOG_ATTRIBUTE_APPENDER" class="ch.qos.logback.core.rolling.RollingFileAppender">
<file>${org.apache.nifi.bootstrap.config.log.dir}/nifi-attribute.log</file>
<rollingPolicy class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
<fileNamePattern>${org.apache.nifi.bootstrap.config.log.dir}/nifi-attribute-%d{yyyy-MM-dd}.%i.log</fileNamePattern>
<maxFileSize>10MB</maxFileSize>
<maxHistory>10</maxHistory>
</rollingPolicy>
<encoder class="ch.qos.logback.classic.encoder.PatternLayoutEncoder">
<pattern>%date %-5level [%thread] %logger - %msg%n</pattern>
</encoder>
</appender>
```
and this to the loggers
```
<logger name="org.apache.nifi.processors.standard.LogAttribute" level="INFO" additivity="false">
<appender-ref ref="LOG_ATTRIBUTE_APPENDER"/>
</logger>
```
After this configuration, you will be able to see the outcome of each LogAttribute processor's logs. 


## Prerequisites

### Docker Installation

Ensure Docker is installed on your system. Follow the [official Docker installation guide](https://docs.docker.com/get-docker/).

## NiFi Processors in the Flow

- [1. GetFile](#1-getfile)
- [2. UnpackContent](#2-unpackcontent)
- [3. RouteOnAttribute](#3-routeonattribute)
- [4. PartitionRecord](#4-partitionrecord)
- [5. UpdateAttribute](#5-updateattribute)
- [6. MergeContent](#6-mergecontent)
- [7. SplitText](#7-splittext)
- [8. LogAttribute](#8-logattribute)
- [9. PutFile](#9-putfile)
- [Flow Overview](#flow-overview)


This document explains the purpose and functionality of each NiFi processor used in the flow:

---

## 1. GetFile
- **Purpose**: Reads files from a local directory.
- **Key Properties**:
  - **Input Directory**: The directory to scan for files.
  - **Keep Source File**: Option to delete or retain the original file after processing.
- **Use Case**: Starts the flow by ingesting files into NiFi.

---

## 2. UnpackContent
- **Purpose**: Unpacks files that are compressed (e.g., ZIP, TAR, GZIP).
- **Key Properties**:
  - **Packaging Format**: Specifies the format of the archive to unpack.
- **Use Case**: Extracts content from compressed files for further processing.

---

## 3. RouteOnAttribute
- **Purpose**: Routes FlowFiles to different relationships based on attributes.
- **Key Properties**:
  - **Routing Rules**: Define conditions based on attributes using NiFi Expression Language.
- **Use Case**: Splits FlowFiles into different paths for custom processing.

---

## 4. PartitionRecord
- **Purpose**: Partitions data within a FlowFile into smaller chunks based on record content.
- **Key Properties**:
  - **Record Reader/Writer**: Specifies the format (e.g., JSON, CSV) for reading and writing records.
  - **Partitioning Field(s)**: Fields to partition the data on.
- **Use Case**: Organizes records into logical groups for efficient downstream processing.

---

## 5. UpdateAttribute
- **Purpose**: Modifies or adds attributes to FlowFiles.
- **Key Properties**:
  - **Attribute Updates**: Define new attributes or modify existing ones using static values or expressions.
- **Use Case**: Adds metadata or updates properties for routing or downstream processing.

---

## 6. MergeContent
- **Purpose**: Merges multiple FlowFiles into a single FlowFile.
- **Key Properties**:
  - **Merge Strategy**: Defines how files are combined (e.g., binary concatenation, Defragment).
  - **Minimum/Maximum Number of Entries**: Controls how many files are merged.
- **Use Case**: Combines related FlowFiles into a single file for easier processing.

---

## 7. SplitText
- **Purpose**: Splits text-based FlowFiles into smaller pieces.
- **Key Properties**:
  - **Line Count Per Split**: Determines the number of lines in each output FlowFile.
- **Use Case**: Breaks large text files into manageable chunks for processing.

---

## 8. LogAttribute
- **Purpose**: Logs the attributes of FlowFiles to NiFi’s log files.
- **Key Properties**:
  - **Log Level**: Controls the verbosity (e.g., INFO, DEBUG).
- **Use Case**: Debugging and monitoring FlowFile attributes during processing.

---

## 9. PutFile
- **Purpose**: Writes FlowFiles to a local directory.
- **Key Properties**:
  - **Directory**: Target directory for the output files.
  - **Conflict Resolution Strategy**: Defines how to handle files with the same name.
- **Use Case**: Saves the final output to disk.

---

### Flow Overview
1. **Ingestion**: The flow begins with `GetFile` to read files.
2. **Decompression**: `UnpackContent` processes compressed files.
3. **Routing**: `RouteOnAttribute` directs files based on their metadata.
4. **Partitioning and Transformation**: `PartitionRecord` and `UpdateAttribute` organize and enhance data.
5. **Combination and Splitting**: `MergeContent` and `SplitText` handle file and data size adjustments.
6. **Monitoring**: `LogAttribute` provides insights into FlowFile attributes.
7. **Output**: `PutFile` writes processed files to a specified location.

--- 


## Troubleshooting

- **Container Fails to Start**: Check the logs using `docker logs nifi2` for any startup issues
- **Port Conflicts**: Ensure no other services are using port 8443 on the host machine

## License

[Add your license information here]

## Contributing

[Add contribution guidelines here]

