from RIG.src.Utils.GUI import run_gui
demo = run_gui()
